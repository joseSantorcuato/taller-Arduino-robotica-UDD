var class_sample =
[
    [ "Sample", "class_sample.html#a0a22d5d06e5665853432fe1949e9d514", null ],
    [ "Sample", "class_sample.html#ac9a043d47ab143f7a4d9370cf9f2f02d", null ],
    [ "atIndex", "class_sample.html#a86948f48dcdc0cb19f6e256ece70149d", null ],
    [ "isPlaying", "class_sample.html#ae4fa817151691ece9d2a91a0c0c03007", null ],
    [ "next", "class_sample.html#a087e0da33436c9bfce1f462df50ac2a9", null ],
    [ "phaseIncFromFreq", "class_sample.html#a18e72ecdb7bac8d41038b785d6deba58", null ],
    [ "rangeWholeSample", "class_sample.html#a8a012ae52ee028222118f6bba5c7fb33", null ],
    [ "setEnd", "class_sample.html#a9713e2d38b94e629c06916a7543ef48f", null ],
    [ "setFreq", "class_sample.html#aa0c37457f99def5c7036c6b6d9ee43fc", null ],
    [ "setFreq", "class_sample.html#a4d5840157e98024537ae10cd27ff9f9e", null ],
    [ "setFreq_Q24n8", "class_sample.html#a903c2d634b10ac531c3c9f6a35fcb046", null ],
    [ "setLoopingOff", "class_sample.html#accfdc762cd47425824179bff4cd2a78f", null ],
    [ "setLoopingOn", "class_sample.html#a40e76011d841b84d2d54bf2cec6c4d5f", null ],
    [ "setPhaseInc", "class_sample.html#aaff03b2a14f8f0f79c13840948151a1d", null ],
    [ "setStart", "class_sample.html#a01836f7624ea574e966e775377d5bf11", null ],
    [ "setTable", "class_sample.html#ade1401f231c920576b1eea2776ac591f", null ],
    [ "start", "class_sample.html#a49ab98acdfb4f81a8860ad21876bdc18", null ],
    [ "start", "class_sample.html#abb7084b95a6141843ede8025cdd726ac", null ]
];